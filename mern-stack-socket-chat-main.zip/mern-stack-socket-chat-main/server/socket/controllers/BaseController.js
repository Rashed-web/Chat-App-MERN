export default class BaseController {
  socket;

  constructor(socket) {
    this.socket = socket;
  }
}
