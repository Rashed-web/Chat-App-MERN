import Typography from "@mui/material/Typography";

export default function Home() {
  return <Typography>Welcome to my Chat App</Typography>;
}
